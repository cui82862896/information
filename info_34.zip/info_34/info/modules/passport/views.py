import re
from datetime import datetime
from random import randint
from flask import current_app, jsonify
from flask import make_response
from flask import request
from flask import session

from info import constants, db
from info import redis_store
from info.lib.yuntongxun.sms import CCP
from info.models import User
from info.response_code import RET
from info.utils.captcha.captcha import captcha
from info.modules.passport import passport_blu


"""
1. 需求分析（我们要干什么）
2. 我们需要什么
3. 把步骤写出来
4. 实现代码

"""
@passport_blu.route('/image_code')
def get_image_code():
    """
    1.  前端需要 生成一个 唯一的code_id  在请求的时候传递给后端服务器

    2. 后台应该先接收这个 code_id
    3. 生成一个图片验证码 和 获取验证码图片的内容
    4. 将图片验证码的内容 保存起来（code_id: value）
    5. 将图片返回给前端

    """
    # 2. 后台应该先接收这个 code_id
    code_id=request.args.get('code_id')
    # 3. 生成一个图片验证码 和 获取验证码图片的内容
    # name: 图片的名字
    # text: 图片验证码的内容（4个随机字符）
    # image: 二进制图片
    name, text,image = captcha.generate_captcha()
    # 4. 将图片验证码的内容 保存起来（code_id: value）
    # redis
    # 我们在访问外界资源（Redis,database,file）的时候 外界资源不知道会发生什么变化，
    # 所以我们要捕获其中的异常
    try:
        # setex key seconds value
        # redis_store.setex('img_'+code_id,300,text)
        # from info import redis_store
        redis_store.setex('img_'+code_id,constants.IMAGE_CODE_REDIS_EXPIRES,text)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DATAERR,errmsg='redis保存失败')

    current_app.logger.info(text)

    # 5. 将图片返回给前端
    response=make_response(image)
    #告知浏览器 我们返回的是 图片
    response.headers['Content-Type']='image/jpeg'

    return response


"""
1. 前端应该将 手机号，图片验证码，图片验证码编号 发送给后端

2. 后端要接收数据
3. 三个参数都必须有
4. 判断手机号是否符合规则
5. 判断手机号是否注册
6. 判断图形验证码是否正确
7. 生成一个随机短信验证码
8. 使用云通讯进行发送
9. 根据发送结果进行判断       保存
10. 返回相应
"""
@passport_blu.route('/sms_code',methods=['POST'])
def send_sms_code():
    # 2. 后端要接收数据(json)
    # 接收 json数据
    data = request.json
    mobile=data.get('mobile')
    image_code=data.get('image_code')
    image_code_id=data.get('image_code_id')
    # 3. 三个参数都必须有
    if not all([mobile,image_code,image_code_id]):
        return jsonify(errno=RET.PARAMERR,errmsg='参数不全')
    # 4. 判断手机号是否符合规则
    if not re.match(r'1[3-9][0-9]{9}',mobile):
        return jsonify(errno=RET.PARAMERR,errmsg='手机号格式不正确')
    # 5. 判断手机号是否注册
    count = User.query.filter(User.mobile==mobile).count()
    # User.query.filter_by(mobile=mobile)
    if count>0:
        return jsonify(errno=RET.DATAEXIST,errmsg='手机号以注册')
    # 6. 判断图形验证码是否正确
    # 6.1 获取用户提交的验证码
    # 6.2 获取redis的验证码
    try:
        redis_code=redis_store.get('img_'+image_code_id)
        if redis_code:
            redis_code=redis_code.decode()

            # 删除图片验证码
            redis_store.delete('img_'+image_code_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DATAERR,errmsg='redis数据问题')

    # 因为redis_code 是有时效的 需要判断它有没有
    if not redis_code:
        return jsonify(errno=RET.DATAERR,errmsg='图片验证码以过期')

    # 6.3 比对
    if image_code.lower() != redis_code.lower():
        return jsonify(errno=RET.DATAERR,errmsg='验证码不一致')
    # 7. 生成一个随机短信验证码
    # 补足六位
    sms_code = '%06d'%randint(0,999999)
    # 8. 使用云通讯进行发送
    # to: 给谁发
    # data: [sms_code, 5] 您的验证码为{1}，请于{2}内正确输入，如非本人操作，请忽略此短信。
    # templateId: 我们只能用 1
    result = CCP().send_template_sms(mobile,[sms_code,constants.SMS_CODE_REDIS_EXPIRES/60],1)
    # 9. 根据发送结果进行判断
    # 保存
    # if result != 0:
    #     return jsonify(errno=RET.THIRDERR,errmsg='发送失败')

    try:
        # setex(key,seconds,value)
        redis_store.setex('sms_'+mobile,constants.SMS_CODE_REDIS_EXPIRES,sms_code)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DATAERR,errmsg='发送失败')

    # 10. 返回相应
    return jsonify(errno=RET.OK,errmsg='ok')



"""
注册：
    手机号，短信验证码，密码

    1. 接收参数
    2. 判断这3个参数都有值
    3. 对我们的短信验证码进行验证
    4. 创建用户
    5. 保存登陆状态（ 用户注册成功之后，默认就登陆了）
    6. 返回相应

"""

@passport_blu.route('/register',methods=['POST'])
def register():
    # 1. 接收参数
    mobile=request.json.get('mobile')
    sms_code=request.json.get('sms_code')
    password=request.json.get('password')
    # 2. 判断这3个参数都有值
    if not all([mobile,sms_code,password]):
        return jsonify(errno=RET.PARAMERR,errmsg='参数不全')
    # 3. 对我们的短信验证码进行验证
    # 3.1 获取用户提交的
    # 3.2 获取 redis的
    try:
        redis_sms_code=redis_store.get('sms_'+mobile)
        # 1. 短信验证码有一个时效
        # 2. 短信验证码获取的是 redis数据，redis数据获取出来的是 bytes类型
        # 3. 获取了redis的 短信验证码（图片验证码）之后就要 删除
        if redis_sms_code:
            redis_sms_code=redis_sms_code.decode()

            #删除
            redis_store.delete('sms_'+mobile)

    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DATAERR,errmsg='数据错误')
    # 3.3 比对
    # 如果没有短信验证码 ，返回错误
    if not redis_sms_code:
        return jsonify(errno=RET.NODATA,errmsg='短信验证码过期')

    if redis_sms_code != sms_code:
        return jsonify(errno=RET.DATAERR,errmsg='验证码不一致')
    # 4. 创建用户
    user = User()
    user.mobile=mobile
    user.password=password
    user.nick_name=mobile

    try:
        db.session.add(user)
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()

    # 5. 保存登陆状态（ 用户注册成功之后，默认就登陆了）
    # session数据是保存在服务器端，不容易被用户操作，所以我们保存在session中
    session['user_id']=user.id
    session['mobile']=mobile
    session['nick_name']=mobile

    # 6. 返回相应
    return jsonify(errno=RET.OK,errmsg='注册成功')



"""
登陆

前端需要将 手机号和密码传递过来

1. 后端要接收数据  json
2. 判断数据是否齐全
3. 根据用户名查询用户记录
4. 如果有记录说明用户注册过，判断密码是否正确
5. 如果正确 应该记录 登陆信息
6. 返回相应

"""

@passport_blu.route('/login',methods=['POST'])
def login():
    # 1.后端要接收数据
    mobile=request.json.get('mobile')
    password=request.json.get('password')
    # 2. 判断数据是否齐全
    if not all([mobile,password]):
        return jsonify(errno=RET.PARAMERR,errmsg='参数不全')
    # 3. 根据用户名查询用户记录
    try:
        user=User.query.filter_by(mobile=mobile).first()
        # user=User.query.filter(User.mobile==mobile).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR,errmsg='数据库错误')

    # 进行查询的时候 user 有可能 没有查询到符合条件的 这个时候 user是没有值的
    if not user:
        return jsonify(errno=RET.NODATA,errmsg='您暂未注册')

    # 4. 如果有记录说明用户注册过，判断密码是否正确
    # check_passowrd 密码正确 返回True
    # check_passowrd 密码不正确 返回False
    #
    if not user.check_passowrd(password):
        return jsonify(errno=RET.DATAERR,errmsg='用户名或密码错误')
    # 5. 如果正确 应该记录 登陆信息
    session['user_id']=user.id
    session['nick_name']=user.nick_name
    session['mobile']=user.mobile

    # 记录用户的最后登陆时间
    user.last_login=datetime.now()
    # 更新了数据之后 要进行数据的提交
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()

    # 6. 返回相应
    return jsonify(errno=RET.OK,errmsg='ok')

@passport_blu.route('/logout',methods=['post'])
def logout():
    """
    就是将登陆/注册 保存的session数据清除
    :return:
    """
    del session['user_id']
    session.pop('nick_name')
    session.pop('mobile')
    # 因为我们也已经添加了 is_admin  退出的时候 也要移除
    session.pop('is_admin')

    return jsonify(errno=RET.OK,errmsg='ok')



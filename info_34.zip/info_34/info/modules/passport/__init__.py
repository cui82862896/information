from flask import Blueprint


passport_blu=Blueprint('passport',__name__,url_prefix='/passport')

from . import views

# @passport_blu.route('/image_code')
# def get_image_code():
#
#     return 'image_code'
#     pass

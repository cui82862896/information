from flask import Blueprint
from flask import redirect
from flask import render_template
from flask import request
from flask import session
from flask import url_for

admin_blu = Blueprint('admin',__name__,url_prefix='/admin')

@admin_blu.before_request
def before_request():
    if not request.url.endswith('login'):
        # 每次请求前 我都进行判断
        user_id = session.get('user_id',None)
        is_admin=session.get('is_admin',False)

        if not user_id :

            # return redirect('/admin/login')
            return redirect(url_for('admin.admin_login'))
            # return redirect('/')

        if not is_admin:
            # /admin/login
            # return redirect('/admin/login')
            return redirect(url_for('admin.admin_login'))
            # return redirect('/')



from . import views



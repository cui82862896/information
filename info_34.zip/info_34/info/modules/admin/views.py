import time
from datetime import datetime, timedelta

from flask import current_app
from flask import g
from flask import redirect
from flask import render_template, jsonify
from flask import request
from flask import session
from flask import url_for

from info import db
from info.models import User, News, Category
from info.modules.admin import admin_blu

# 后台首页
from info.response_code import RET
from info.utils.common import login_user_data


@admin_blu.route('/')
@login_user_data
def admin_home():

    user = g.user

    if not user:
        return redirect(url_for('admin.admin_login'))

    data = {
        'user_info':user.to_dict()
    }

    return render_template('admin/index.html',data=data)



#后台登陆页面
@admin_blu.route('/login',methods=['GET','POST'])
def admin_login():
    if request.method=='GET':

        # 如果用户已经登陆 就给他跳转到 admin 首页
        # user_id = session.get('user_id',None)
        # is_admin = session.get('is_admin',False)
        #
        # if user_id and is_admin:
        #     return redirect(url_for('admin.admin_home'))

        return render_template('admin/login.html')

    """
    登陆的业务逻辑

    1. 接收数据
    2. 用户名和密码必须有
    3. 根据用户进行查询
    4. 判断是否有该用户
    5. 检测密码是否正确
    6. 用户必须是管理员
    7. 保存登陆状态( 管理员 也是需要标记出来的)
    8. 返回相应
    """

    # 1. 接收数据
    username = request.form.get('username')
    pwd = request.form.get('password')
    # 2. 用户名和密码必须有
    if not all([username,pwd]):
        return render_template('admin/login.html',errmsg='参数不全')
        # return jsonify(errno=RET.PARAMERR,errmsg='参数不全')
    # 3. 根据用户进行查询
    try:
        user = User.query.filter_by(mobile=username).first()
    except Exception as e:
        return render_template('admin/login.html', errmsg='查询失败')
        # return jsonify(errno=RET.DBERR,errmsg='查询失败')
    # 4. 判断是否有该用户
    if not user:
        return render_template('admin/login.html', errmsg='无该用户')
    # 5. 检测密码是否正确
    if not user.check_passowrd(pwd):
        return render_template('admin/login.html', errmsg='用户名或密码不正确')
    # 6. 用户必须是管理员
    if not user.is_admin:
        return render_template('admin/login.html', errmsg='您不是管理员')
    # 6. 保存登陆状态( 管理员 也是需要标记出来的)
    session['user_id']=user.id
    session['nick_name']=user.nick_name
    session['mobile']=user.mobile
    session['is_admin']=True
    # 7. 返回相应
    # url_for('蓝图名.试图函数名')
    return redirect(url_for('admin.admin_home'))


@admin_blu.route('/user_count')
def user_count():

    """
    # 查询总用户数
    # 查询每月新增
    # 查询每天新增

    :return:
    """
    # 查询总用户数
    total_count = 0
    try:
        total_count = User.query.filter_by(is_admin=False).count()
    except Exception as e:
        current_app.logger.error(e)
    # 查询每月新增
    month_count = 0
    # month_date = 2018-12-01
    now = time.localtime()

    # year,month,day
    # 先组织时间 字符串
    month_str = '%d-%02d-01'%(now.tm_year,now.tm_mon)
    # 字符串转化为 date
    # strptime(date_str, 格式)
    # 格式 %Y year  %m month  %d day
    month_date = datetime.strptime(month_str,'%Y-%m-%d')
    try:
        month_count = User.query.filter(User.is_admin==False,
                                        User.create_time>month_date).count()
    except Exception as e:
        current_app.logger.error(e)

    # 查询每天新增
    day_str = '%d-%02d-%02d'%(now.tm_year,now.tm_mon,now.tm_mday)

    day_date = datetime.strptime(day_str,'%Y-%m-%d')

    day_count = 0
    try:
        day_count = User.query.filter(User.is_admin==False,
                                        User.create_time>day_date).count()
    except Exception as e:
        current_app.logger.error(e)

    """
    我们按照每天的人员变化 来组织数据

    """
    active_date = []
    active_count = []
    # 2018-12-25
    # date_str
    # '%Y-%m-%d'

    # datetime.now() 获取的是 年-月-日 时:分:秒
    # datetime.now().strftime('%Y-%m-%d')  str类型  年-月-日
    # datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d') 是将
    # 字符串 转换位 date类型
    today_date = datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    # 12-25   12-24         10
    # 12-24    12-23        15
    # 12-23    12-22         10

    for i in range(0,31):
        begin_date = today_date-timedelta(days=i)
        end_date = today_date-timedelta(days=(i-1))

        #将开始的时间 转换位字符串 添加到列表中
        active_date.append(begin_date.strftime('%Y-%m-%d'))

        count = User.query.filter(User.is_admin==False,
                                     User.create_time>begin_date,
                                     User.create_time<end_date).count()

        active_count.append(count)

    # 我们的数据需要颠倒一下
    active_date.reverse()
    active_count.reverse()

    data = {
        'total_count':total_count,
        'month_count':month_count,
        'day_count':day_count,
        'active_count':active_count,
        'active_date':active_date
    }

    return render_template('admin/user_count.html',data=data)


@admin_blu.route('/user_list')
def user_list():
    """

    1. 接收分页参数
    2. 对分页进行校验
    3. 进行分页查询
    4. 组织数据


    :return:
    """
    return render_template('admin/user_list.html')


@admin_blu.route('/news_review')
def news_review():

    """
    1. 获取分页参数
    2. 对分页参数进行 处理
    3. 分页查询
    4. 组织数据

    :return:
    """

    # 1. 获取分页参数
    p = request.args.get('p','1')
    # 2. 对分页参数进行 处理
    try:
        p = int(p)
    except Exception as e:
        p = 1
    # 3. 分页查询
    try:
        # paginate = News.query.filter(News.status!=0).order_by(News.create_time.desc()).paginate(per_page=2,page=p)
        paginate = News.query.filter().order_by(News.create_time.desc()).paginate(per_page=2,page=p)
        items = paginate.items
        current_page = paginate.page
        total_page = paginate.pages
    except Exception as e:
        return jsonify(errno=RET.DBERR,errmsg='为查询到数据')
    # 4. 组织数据
    news_list = []
    for item in items:
        news_list.append(item.to_review_dict())

    data = {
        'news':news_list,
        'total_count':total_page,
        'current_page':current_page

    }

    return render_template('admin/news_review.html',data=data)


@admin_blu.route('/news_review_detail',methods=['GET','POST'])
def news_review_detail():
    """
    1. 通过 request.args 来获取 news_id
    2. 通过news_id 查询新闻
    3. 组织数据


    :return:
    """
    if request.method == 'GET':
        news_id = request.args.get('news_id')

        if not news_id:
            return jsonify(errno=RET.PARAMERR,errmsg='参数错误')

        try:
            news = News.query.get(news_id)
        except Exception as e:
            return jsonify(errno=RET.NODATA,errmsg='查无此文')

        if not news:
            return jsonify(errno=RET.NODATA, errmsg='查无此文')

        data = {
            'news':news.to_dict()
        }

        return render_template('admin/news_review_detail.html',data=data)

    """
    审核数据

    前端需要把 news_id, action ['accept','reject']
    入股拒绝 需要传递 原因

    1. 接收form数据
    2. 判断数据是否都传递过来 (news_id, action)
    3. action 必须是  ['accept','reject']
    4. new_id 必须有
    5. 根据 action 实现业务逻辑

    """

    # 1. 接收form数据
    news_id = request.json.get('news_id')
    action = request.json.get('action')

    # 2.判断数据是否都传递过来
    if not all([news_id,action]):
        return jsonify(errno=RET.PARAMERR, errmsg='参数错误')
    #
    #     3.1 news_id 判断 此条新闻必须有（查询数据库就知道了）
    if news_id is None:
        return jsonify(errno=RET.PARAMERR, errmsg='参数错误')

    try:
        news = News.query.get(news_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg='数据库查询失败')
    if not news:
        return jsonify(errno=RET.NODATA, errmsg='没有此条数据')

    # 3.2 action
    if action not in ['accept', 'reject']:
        return jsonify(errno=RET.PARAMERR, errmsg='参数错误')
    # 4. 根据用户的行为 进行业务逻辑的实现
    if action == 'accept':
       news.status = 0

    else:
       # 拒绝 需要拒绝的原因
        reason = request.form.get('reason')
        if not reason:
            return jsonify(errno=RET.PARAMERR, errmsg='参数错误')

        news.status=-1
        news.reason=reason

    # 5. 更新数据
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
    # 6. 返回相应
    return jsonify(errno=RET.OK, errmsg='操作成功')



@admin_blu.route('/news_type')
def news_type():
    # 获取分类信息
    try:
        categories = Category.query.all()
    except Exception as e:
        current_app.logger.error(e)

    # 把查询的对象列表转换为 字典列表
    categories_list = []
    for item in categories:
        categories_list.append(item.to_dict())

    # 有一个小问题: 需要把最新的数据 删除
    categories_list.pop(0)

    return render_template('admin/news_type.html', data={'categories': categories_list})


@admin_blu.route('/add_category',methods=['POST'])
def add_type():
    """
    新增分类和修改分类

    更新(修改): 把 分类id 和分类名 一起提交
    新增分类:  就是新增一个 分类的名字

    1. 接收数据
    2. 判断是否传递过来了 分类的名字
    3. 根据是否有传递 分类id,进行业务逻辑判断
    4. 有分类id就是更新数据
    5. 没有分类id就是 新增分类数据

    :return:
    """
    # 1. 接收数据
    category_name = request.json.get('name')
    category_id = request.json.get('id')
    # 2. 判断是否传递过来了 分类的名字
    if not category_name:
        return jsonify(errno=RET.PARAMERR,errmsg='参数错误')
    # 3. 根据是否有传递 分类id,进行业务逻辑判断
    if category_id:
        # 4. 有分类id就是更新数据

        try:
            category=Category.query.get(category_id)
        except Exception as e:
            return jsonify(errno=RET.DATAERR,errmsg='数据错误')

        if not category:
            return jsonify(errno=RET.DATAERR, errmsg='数据错误')

        category.name=category_name


    else:
        # 5. 没有分类id就是 新增分类数据
        category = Category()
        category.name=category_name
        db.session.add(category)

    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()

    return jsonify(errno=RET.OK,errmsg='ok')


"""
127.0.0.1:80
浏览器 --> Nginx


80: --> http://127.0.0.1:5000
Nginx --> Gunicorn



Gunicorn --> Flaks程序


"""







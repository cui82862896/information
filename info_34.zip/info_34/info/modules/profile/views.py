from flask import current_app
from flask import g, jsonify
from flask import render_template
from flask import request
from flask import session

from info import constants
from info import db
from info.models import Category, News
from info.modules.profile import profile_blu
from info.response_code import RET
from info.utils.common import login_user_data
from info.utils.image_storage import storage


@profile_blu.route('/info')
@login_user_data
def user_info():

    user = g.user

    return render_template('news/user.html',data={'user_info': user.to_dict() if user else None })



"""
   修改数据

   1. 接收数据
   2. 校验数据
   3. 更新数据
   4. 返回相应
"""
@profile_blu.route('/base_info',methods=['GET','POST'])
@login_user_data
def user_base_info():
    # GET 大写
    user = g.user
    # 判断用户必须登陆
    if user is None:
        return jsonify(errno=RET.SESSIONERR,errmsg='没有登陆')

    if request.method == 'GET':


        return render_template('news/user_base_info.html',data={'user_info':user.to_dict() if user else None})
    else:
        # POST 请求修改数据
        """
        1. 接收参数
        2. 判断参数 ( 是否都传递过来 )
        3. 更新数据
        4. 返回相应
        """
        # 1. 接收参数
        signature = request.json.get('signature')
        nick_name = request.json.get('nick_name')
        gender = request.json.get('gender')
        # 2. 判断参数 ( 是否都传递过来 , 判断某些值 是否满足条件)

        if not all([signature,nick_name,gender]):
            return jsonify(errno=RET.PARAMERR,errmsg='参数不全')

        if gender not in ['MAN','WOMAN']:
            return jsonify(errno=RET.PARAMERR,errmsg='参数不正确')

        # 3. 更新数据

        user.gender=gender
        user.nick_name=nick_name
        user.signature=signature


        #更新 sesion中的数据
        session['nick_name']=nick_name

        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
        # 4. 返回相应
        return jsonify(errno=RET.OK,errmsg='ok')


# @profile_blu.route('/update_info',methods=['POST'])
# @login_user_data
# def update_info():
#     """接收用户更新资料"""
#     pass


@profile_blu.route('/pic_info',methods=['get','post'])
@login_user_data
def user_pic_info():
    user = g.user

    if request.method == 'GET':
        return render_template('news/user_pic_info.html',data={'user_info':user.to_dict() if user else None})


    """
    POST 上传图片

    1. 接收数据( 图片 )
    2. 上传到七牛云中 ,获取到 返回的图片名字
    3. 更新用户的头像信息
    4. 返回相应
    """
    # 1. 接收数据( 图片 )
    # print(request.files)
    avatar = request.files.get('avatar')
    if not avatar:
        return jsonify(errno=RET.PARAMERR,errmsg='参数错误')
    # 2. 上传到七牛云 (读取 图片的内容 二进制)中 ,获取到 返回的图片名字
    # 读取 图片的内容 二进制
    try:
        # 调用 read方法读取数据
        data = avatar.read()
        # 调用七牛云的存储
        path = storage(data)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.THIRDERR,errmsg='上传失败')
    # 3. 更新用户的头像信息
    user.avatar_url = path

    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
    # 4. 返回相应
    return jsonify(errno=RET.OK,errmsg='ok',data={'avatar_url':constants.QINIU_DOMIN_PREFIX + path})


# print(request)
# print(current_app)

@profile_blu.route('/pass_info')
@login_user_data
def user_pass_info():

    """

    GET :展示数据

    POST: 修改密码
    1. 接收参数
    2. 三个参数必须都有
    3. 两次密码必须一致
    4. 查询用户 当前的密码输入是否正确
    5. 修改密码
    6. 返回相应
    :return:
    """
    pass


@profile_blu.route('/collection')
@login_user_data
def user_collection():
    """
    1. 先接收 分页参数 page     per_page
    2. 查询数据
        模型类名.query.paginate()
    3. 传递给模板进行展示

    :return:
    """

    user = g.user

    # 1. 先接收 分页参数 page
    try:
        page = request.args.get('page','1')
        page = int(page)
    except Exception as e:
        current_app.logger.error(e)
        page = 1
        # return jsonify(errno=RET.PARAMERR,errmsg='参数错误')
    # 2. 查询数据
    try:
        #     模型类名.query.paginate()
        paginate = user.collection_news.paginate(page=page, per_page=2)
        #  第二页的 2条数据
        # 当前页码是所有数据
        items = paginate.items

        current_page = paginate.page

        total_page = paginate.pages

    except Exception as e:
        return jsonify(errno=RET.DBERR,errmsg='数据获取失败')

    collections = []
    for item in items:
        collections.append(item.to_basic_dict())
    # 3. 传递给模板进行展示

    return render_template('news/user_collection.html',
                           collections=collections,
                           current_page=current_page,
                           total_page=total_page)


@profile_blu.route('/news_release',methods=['GET','POST'])
@login_user_data
def user_news_release():

    user = g.user
    if not user:
        return jsonify(errno=RET.SESSIONERR,errmsg='您暂未登陆')

    if request.method == 'GET':

        # 获取分类信息
        try:
            categories = Category.query.all()
        except Exception as e:
            current_app.logger.error(e)

        # 把查询的对象列表转换为 字典列表
        categories_list = []
        for item in categories:
            categories_list.append(item.to_dict())

        # 有一个小问题: 需要把最新的数据 删除
        categories_list.pop(0)


        return render_template('news/user_news_release.html',data={'categories':categories_list})


    """
    POST 获取发布是新闻数据
    1.接收参数
    2. 参数进行校验 ,必须都传递进来
    3. 图片的单独处理, 我们保存的是 图片的 url 我们先把图片上传到七牛云中
    4. 新增新闻
    5. 保存到数据库
    6. 返回


    """



    # 1.接收参数
    title = request.form.get('title')
    category_id=request.form.get('cagtegory_id')
    content=request.form.get('content')
    digest=request.form.get('digest')
    index_image=request.files.get('index_image')

    # 2. 参数进行校验 ,必须都传递进来
    if not all([title,category_id,content,digest,index_image]):
        return jsonify(errno=RET.PARAMERR,errmsg='参数不全')



    # 3. 图片的单独处理, 我们保存的是 图片的 url 我们先把图片上传到七牛云中
    try:
        data = index_image.read()
        path = storage(data)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.THIRDERR,errmsg='上传失败')


    # 4. 新增新闻
    news = News()
    news.title=title
    news.source='个人'
    news.digest=digest
    news.content=content
    news.index_image_url = constants.QINIU_DOMIN_PREFIX + path
    news.category_id=category_id
    news.user_id = user.id
    news.status=1 # 0代表审核通过，1代表审核中，-1代表审核不通过
    # 5. 保存到数据库
    try:
        db.session.add(news)
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
    # 6. 返回
    return jsonify(errno=RET.OK,errmsg='ok')



@profile_blu.route('/user_follow')
@login_user_data
def follow_list():

    """

    1. 获取参数,进行校验
    2. 进行分页
    3. 返回数据
    :return:
    """

    user = g.user


    try:
        p = request.args.get('p','1')
        p = int(p)
    except Exception as e:
        p = 1


    try:
        paginate = user.followers.paginate(page=p,per_page=2)

        items  = paginate.items
        current_page = paginate.page
        total_page= paginate.pages

    except Exception as e:
        return jsonify(errno=RET.DBERR,errmsg='没有数据')

    follows = []
    for item in items:
        follows.append(item.to_dict())

    data = {
        'current_page':current_page,
        'total_page':total_page,
        'users':follows
    }

    return render_template('news/user_follow.html',data=data)



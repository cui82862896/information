from flask import Blueprint

index_blu=Blueprint('index',__name__)

"""
我们的试图在加载的时候 只加载 init.py文件，不会加载views

当我们将试图 抽取到 views中之后, 这个时候 就找不到试图

"""
from . import views


#
# @index_blu.route('/')
# def index():
#
#     return 'index'
#
#
# @index_blu.route('/detail')
# def detail():
#     #详情试图
#     return 'detail'
# from info import index_blu
from flask import current_app, jsonify
from flask import g
from flask import render_template
from flask import request
from flask import session

from info import constants
from info.models import User, News, Category
from info.modules.index import index_blu
from info.response_code import RET
from info.utils.common import login_user_data


@index_blu.route('/')
@login_user_data
def index():
    ##########################以下是用户信息##########################################
    # 因为我们将登陆状态保存在session中，我们是可以获取session数据的
    # user_id=session.get('user_id')
    #
    # user=None
    # if user_id:
    #     # 如果user_id 有值 说明用户登陆，登陆之后我们查询用户的信息
    #     try:
    #         user=User.query.get(user_id)
    #     except Exception as e:
    #         current_app.logger.error(e)
    user=g.user
    # user.to_dict() 可以不调用 to_dict()
    #  直接传对象。 为了让大家适应后边的django 所以我们返回字典
    """
    user.to_dict() if user else None
    if user:
        return user.to_dict()
    else:
        return None
    """

    ##########################以下是排行列表##########################################

    # 1. 根据点击排行获取制定条数的信息

    try:
        click_list = News.query.order_by(News.clicks.desc()).limit(constants.CLICK_RANK_MAX_NEWS)
    except Exception as e:
        current_app.logger.error(e)

    #  [News,News,News]
    # 将对象列表转换为 字典列表
    # [{},{},{}]
    clicks_news=[]
    for item in click_list:
        clicks_news.append(item.to_dict())

    ##########################以下是分类信息##########################################



    try:
        categories=Category.query.all()
    except Exception as e:
        current_app.logger.error(e)


    # 把查询的对象列表转换为 字典列表
    categories_list=[]
    for item in categories:
        categories_list.append(item.to_dict())


    data = {
        'user_info': user.to_dict() if user else None,
        'clicks_news':clicks_news,
        'categories':categories_list
    }

    return render_template('news/index.html',data=data)
    return 'index'

@index_blu.route('/favicon.ico')
def favicon():

    return current_app.send_static_file('news/favicon.ico')


"""
首页新闻列表的获取

# http://127.0.0.1:5000/news_list?cid=2&page=2&per_page=20
# 因为我们要传递 分类 传递 第几页 所以 我们确定了 url为上边的这个

1. 接收参数
2. 获取参数，并对参数进行判断
3. 组织查询数据
4. 返回数据
"""

@index_blu.route('/news_list')
def get_index_list():
    # 1. 接收参数
    params = request.args
    # 2. 获取参数，并对参数进行判断
    # get(key,default)
    # default 默认值 如果 没有这个key 就使用 默认值

    # 因为用户的行为是无法确定的，所以 我们做 判断 如果url中没有 key，我们就使用默认值
    cid=params.get('cid','1')
    page=params.get('page',1)
    per_page=params.get('per_page',20)

    try:
        page=int(page)
        per_page=int(per_page)
    except Exception as e:
        page=1
        per_page=20

    """
    category_id = 1 的为最新的数据  数据库中 其实是没有最新数据的新闻的
            我们是根据 新闻的时间来获取最新的新闻

    *args
    **kwargs
    *filter 就是解包 就是 把 列表中的数据 一个一个的拿出来
    """
    # filter=[News.status == 0]
    filter = []
    if cid != '1':
        filter.append(News.category_id==cid)

    # 3. 组织查询数据
    try:
        paginate=News.query.filter(*filter).order_by(News.create_time.desc()).paginate(page=page, per_page=per_page)
        #获取所有当前分页的数据
        news = paginate.items
        # 总页数
        total_page=paginate.pages
        #当前页数
        current_page=paginate.page


    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR,errmsg='数据查询失败')
    # 4. 返回数据
    news_list=[]

    for item in news:
        news_list.append(item.to_basic_dict())

    return jsonify(errno=RET.OK,errmsg='ok',
                   news_list=news_list,
                   current_page=current_page,
                   cid=cid,
                   total_page=total_page)


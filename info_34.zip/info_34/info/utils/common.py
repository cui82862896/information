from flask import g
from flask import session

# from info.models import User


def do_index_class(index):

    if index == 1:
        return 'first'
    elif index == 2:
        return 'second'
    elif index == 3:
        return 'third'
    else:
        return ''


import functools
def login_user_data(f):
    # 作用就是 保留 原有函数的一些参数设置 不会被 wrapper修改
    @functools.wraps(f)
    def wrapper(*args,**kwargs):

        user_id = session.get('user_id')

        user = None
        if user_id:
            # 如果user_id 有值 说明用户登陆，登陆之后我们查询用户的信息
            from info.models import User
            user = User.query.get(user_id)

        g.user=user

        return f(*args,**kwargs)




    return wrapper
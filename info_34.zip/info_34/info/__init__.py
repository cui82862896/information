import logging
from logging.handlers import RotatingFileHandler

from flask import Flask
from flask import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from flask_session import Session
from redis import StrictRedis
from config import ProductionConfig,DevelopmentConfig
from config import config
# from info.modules.index import index_blu
# from info.modules.passport import passport_blu
# from info.modules.profile import profile_blu
from info.utils.common import do_index_class

"""
http://140.143.37.139:4999/
https://gitee.com/
https://gitee.com/itcastitheima/info_34.git

down 需要密码

数据表/数据模型的设计思想：

1.比较明显的表 要设计出来，设计出来之后，不要找表和表之间的关系。尽量多的 分析字段
2.找一个安静的时间点 分析表和表之间的关系(需要业务逻辑才能分析出来)

200 ok
404 路由有问题/没有注册蓝图
405 method not allow 方法不被允许
500 内部错误 肯定是代码出问题了

CSRF 总结了两步：
    1.前端需要 传递一个 csrf给后端
        post(请求体):  form
        请求头：
    2.后端我们需要记录这个csrf, 然后进行验证
        session

    3. 后端生成的 csrf_token 是如何传递给 前端的呢？
        我们就是调用钩子函数 在每次相应的时候 都设置 cookie信息
        前端是可以获取cookie信息的

"""
db = SQLAlchemy()

redis_store=None

# app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:mysql@127.0.0.1:3306/info_34'
def create_app(config_name='development'):
    #日志
    setup_log(config_name)

    app=Flask(__name__)
    # config['development']   DevelopmentConfig
    # config['production']  ProductionConfig

    #加载配置文件
    app.config.from_object(config[config_name])

    #创建SQLAlchemy 实例对象
    # db=SQLAlchemy(app)
    db.init_app(app)

    #创建Redis实例
    # sr=StrictRedis(host='192.168.23.5',port=6379)
    """
    在函数外边是一个作用域
    在函数内部是一个作用域
    我们想在函数内部使用函数外部的变量： 使用 global
    """
    global redis_store
    redis_store=StrictRedis(host=config[config_name].REDIS_HOST,port=config[config_name].REDIS_PORT)

    # CSRF的设置 -- 关于原理我们明天(12.23)将
    CSRFProtect(app)

    """
    session是保存在 服务器端
        session(s 小写开头)默认是保存在cookie中的
        所以 小写的session 不能满足我们的需求
        这个时候我们用 大写的Session

    cookie是保存在 浏览器端


    Session
        SESSION_REDIS: 因为我们要将数据保存在 Redis-Server 中，所以我们要连接redis-server
                    连接redis-server 就要有一个客户端
        SESSION_KEY_PREFIX: session数据的前缀，默认是 session:
        SESSION_USE_SIGNER:     session是依赖于cookie的， cookie数据是否进行加密处理
                            是否对我们的cookie数据进行加密的签名处理
        PERMANENT_SESSION_LIFETIME:  设置Session数据的有效期 单位为秒数
    """

    Session(app)

    #注册蓝图
    from info.modules.index import index_blu
    app.register_blueprint(index_blu)

    from info.modules.passport import passport_blu
    app.register_blueprint(passport_blu)

    from info.modules.news import news_blu
    app.register_blueprint(news_blu)

    from info.modules.profile import profile_blu
    app.register_blueprint(profile_blu)


    from info.modules.admin import admin_blu
    app.register_blueprint(admin_blu)
    #一定要注意：返回




    #
    # # 系统自动生成的 csrf_token
    # # 我们来查看一下 源码： 生成的csrf_token系统保存在哪里？
    # # 系统是写入到 session中的
    # csrf_token=generate_csrf()
    @app.after_request
    def after_request(response):

        from flask_wtf.csrf import generate_csrf
        token = generate_csrf()

        response.set_cookie('csrf_token',token)

        return response


    ########################添加过滤器##############################
    app.add_template_filter(do_index_class,'indexclass')

    ########################统一的 404 ##############################
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('news/404.html')
        return '服务器去火星约会了'
        pass
    return app


def setup_log(config_name):
    """配置日志"""

    # 设置日志的记录等级
    logging.basicConfig(level=config[config_name].LOG_LEVEL)  # 调试debug级
    # 创建日志记录器，指明日志保存的路径、每个日志文件的最大大小、保存的日志文件个数上限
    file_log_handler = RotatingFileHandler("logs/log", maxBytes=1024 * 1024 * 100, backupCount=10)
    # 创建日志记录的格式 日志等级 输入日志信息的文件名 行数 日志信息
    formatter = logging.Formatter('%(levelname)s %(filename)s:%(lineno)d %(message)s')
    # 为刚创建的日志记录器设置日志记录格式
    file_log_handler.setFormatter(formatter)
    # 为全局的日志工具对象（flask app使用的）添加日志记录器
    logging.getLogger().addHandler(file_log_handler)

